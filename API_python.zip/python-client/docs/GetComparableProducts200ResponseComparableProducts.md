# GetComparableProducts200ResponseComparableProducts


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calories** | **[{str: (bool, date, datetime, dict, float, int, list, str, none_type)}]** |  | 
**likes** | **[{str: (bool, date, datetime, dict, float, int, list, str, none_type)}]** |  | 
**price** | **[{str: (bool, date, datetime, dict, float, int, list, str, none_type)}]** |  | 
**protein** | [**[GetComparableProducts200ResponseComparableProductsProteinInner]**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**spoonacular_score** | [**[GetComparableProducts200ResponseComparableProductsProteinInner]**](GetComparableProducts200ResponseComparableProductsProteinInner.md) |  | 
**sugar** | **[{str: (bool, date, datetime, dict, float, int, list, str, none_type)}]** |  | 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


