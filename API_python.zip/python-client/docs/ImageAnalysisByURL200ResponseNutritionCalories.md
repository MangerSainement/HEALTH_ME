# ImageAnalysisByURL200ResponseNutritionCalories


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **float** |  | 
**unit** | **str** |  | 
**confidence_range95_percent** | [**ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent**](ImageAnalysisByURL200ResponseNutritionCaloriesConfidenceRange95Percent.md) |  | 
**standard_deviation** | **float** |  | 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


