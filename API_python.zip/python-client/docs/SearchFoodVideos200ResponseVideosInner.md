# SearchFoodVideos200ResponseVideosInner


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** |  | 
**length** | **int** |  | 
**rating** | **float** |  | 
**short_title** | **str** |  | 
**thumbnail** | **str** |  | 
**views** | **int** |  | 
**you_tube_id** | **str** |  | 
**any string name** | **bool, date, datetime, dict, float, int, list, str, none_type** | any string name can be used but the value must be the correct type | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


